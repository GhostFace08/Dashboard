/**
 * user_management.js — User Management page logic (Phase 10)
 *
 * Per decision #4: no real authentication/login enforcement — this is
 * UI + a persisted user list only. Add User modal (username, password,
 * tool-visibility restrictions) → row list with Edit/Delete → Edit modal
 * (same fields, pre-filled).
 *
 * PERSISTENCE — placeholder, same pattern as topology.js's topologyStore:
 *   Backed by localStorage for now (key below) so accounts survive a
 *   reload during review. Every read/write funnels through loadUsers()/
 *   saveUsers() — swapping to a real backend endpoint later means
 *   replacing just those two functions' bodies, same shape.
 *
 *   Passwords are stored as plain text in this placeholder store. That is
 *   ONLY acceptable because there is no real auth behind this yet (decision
 *   #4) — if/when real authentication is introduced, this must be replaced
 *   with a proper backend that hashes credentials server-side. Flagging
 *   this loudly so it isn't missed later.
 *
 * DEPENDENCIES (must load before this file):
 *   config.js  → window.CFG   (TOOLS, for the tool-visibility checkboxes)
 *   api.js     → window.API
 *   common.js  → window.Utils
 */

(function (global) {
  "use strict";

  if (!global.CFG) {
    console.error("[user_management.js] CFG not found — did config.js load?");
    return;
  }

  const TOOLS = global.CFG.TOOLS || [];
  const STORAGE_KEY = "mcp-users-data";

  const state = {
    users: [],
    search: "",
    editingId: null, // null = Add mode, otherwise the user id being edited
    loaded: false,
  };

  /* ─── Store (localStorage-backed placeholder — see doc comment) ─────────── */
  function loadUsers() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { /* fall through to seed */ }
    return seedUsers();
  }

  function saveUsers(users) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
    } catch (e) {
      console.warn("[user_management] failed to persist user list:", e);
    }
  }

  let idCounter = 1;
  function nextId() { return `user-${idCounter++}`; }

  function seedUsers() {
    const users = [
      { id: nextId(), username: "admin", password: "changeme123", tools: ["all"], createdAt: new Date().toISOString() },
      { id: nextId(), username: "ops-viewer", password: "viewonly2024", tools: TOOLS.slice(0, 2).map(t => t.id), createdAt: new Date().toISOString() },
    ];
    saveUsers(users);
    return users;
  }

  /* ─── Rendering: table ────────────────────────────────────────────────── */
  function initials(username) {
    return (username || "?").trim().slice(0, 2).toUpperCase();
  }

  function toolChipsHtml(tools) {
    if (!tools || !tools.length) return `<span class="um-tool-chip">None</span>`;
    if (tools.includes("all")) return `<span class="um-tool-chip all">All Tools</span>`;
    return tools.map(id => {
      const tool = TOOLS.find(t => t.id === id);
      return `<span class="um-tool-chip">${Utils.escapeHtml(tool ? tool.shortName || tool.name : id)}</span>`;
    }).join("");
  }

  function formatDate(iso) {
    try {
      return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    } catch (e) { return "—"; }
  }

  function renderTable() {
    const tbody = document.getElementById("um-table-body");
    if (!tbody) return;

    const q = state.search.trim().toLowerCase();
    const rows = state.users.filter(u => !q || u.username.toLowerCase().includes(q));

    if (!rows.length) {
      tbody.innerHTML = `<tr class="um-empty-row"><td colspan="4">No users found.</td></tr>`;
      return;
    }

    tbody.innerHTML = rows.map(u => `
      <tr data-id="${Utils.escapeHtml(u.id)}">
        <td>
          <div class="um-user-cell">
            <div class="um-avatar">${Utils.escapeHtml(initials(u.username))}</div>
            <span class="um-username">${Utils.escapeHtml(u.username)}</span>
          </div>
        </td>
        <td><div class="um-tool-chips">${toolChipsHtml(u.tools)}</div></td>
        <td><span style="font-family:var(--font-mono);font-size:11px;color:var(--muted-foreground)">${formatDate(u.createdAt)}</span></td>
        <td>
          <div class="um-row-actions">
            <button class="btn-icon um-edit-btn" type="button" data-id="${Utils.escapeHtml(u.id)}" title="Edit"><i data-lucide="pencil"></i></button>
            <button class="btn-icon um-delete-btn" type="button" data-id="${Utils.escapeHtml(u.id)}" title="Delete"><i data-lucide="trash-2"></i></button>
          </div>
        </td>
      </tr>
    `).join("");

    tbody.querySelectorAll(".um-edit-btn").forEach(btn =>
      btn.addEventListener("click", () => openModal(btn.getAttribute("data-id")))
    );
    tbody.querySelectorAll(".um-delete-btn").forEach(btn =>
      btn.addEventListener("click", () => deleteUser(btn.getAttribute("data-id")))
    );

    Utils.refreshIcons();
  }

  /* ─── Tool-visibility checkbox list ───────────────────────────────────── */
  function renderToolCheckboxes(selectedTools) {
    const el = document.getElementById("um-tools-checkbox-list");
    if (!el) return;
    const hasAll = (selectedTools || []).includes("all");

    const allRow = `
      <label class="um-checkbox-row all-row">
        <input type="checkbox" id="um-tool-all" ${hasAll ? "checked" : ""} />
        All Tools
      </label>
    `;
    const toolRows = TOOLS.map(t => `
      <label class="um-checkbox-row">
        <input type="checkbox" class="um-tool-item" value="${Utils.escapeHtml(t.id)}" ${!hasAll && (selectedTools || []).includes(t.id) ? "checked" : ""} ${hasAll ? "disabled" : ""} />
        <span class="swatch" style="background:${t.color || "var(--accent-indigo,#6366f1)"}"></span>${Utils.escapeHtml(t.name)}
      </label>
    `).join("");

    el.innerHTML = allRow + toolRows;

    const allCheckbox = document.getElementById("um-tool-all");
    allCheckbox.addEventListener("change", () => {
      el.querySelectorAll(".um-tool-item").forEach(cb => {
        cb.disabled = allCheckbox.checked;
        if (allCheckbox.checked) cb.checked = false;
      });
    });
  }

  function readSelectedTools() {
    const allCheckbox = document.getElementById("um-tool-all");
    if (allCheckbox && allCheckbox.checked) return ["all"];
    return Array.from(document.querySelectorAll(".um-tool-item:checked")).map(cb => cb.value);
  }

  /* ─── Modal ───────────────────────────────────────────────────────────── */
  function openModal(userId) {
    state.editingId = userId || null;
    const title = document.getElementById("um-modal-title");
    const usernameInput = document.getElementById("um-username-input");
    const passwordInput = document.getElementById("um-password-input");
    const passwordHint = document.getElementById("um-password-hint");

    if (userId) {
      const user = state.users.find(u => u.id === userId);
      if (!user) return;
      title.textContent = "Edit User";
      usernameInput.value = user.username;
      passwordInput.value = user.password;
      passwordHint.textContent = "Leave unchanged unless you want to reset it.";
      renderToolCheckboxes(user.tools);
    } else {
      title.textContent = "Add User";
      usernameInput.value = "";
      passwordInput.value = "";
      passwordHint.textContent = "Minimum 8 characters.";
      renderToolCheckboxes([]);
    }

    document.getElementById("um-modal-overlay").classList.remove("hidden");
    Utils.refreshIcons();
  }

  function closeModal() {
    document.getElementById("um-modal-overlay").classList.add("hidden");
    state.editingId = null;
  }

  function saveModal() {
    const username = document.getElementById("um-username-input").value.trim();
    const password = document.getElementById("um-password-input").value;
    const tools = readSelectedTools();

    if (!username) {
      Utils.showToast ? Utils.showToast("Username is required", "error") : alert("Username is required");
      return;
    }
    if (!password || password.length < 8) {
      Utils.showToast ? Utils.showToast("Password must be at least 8 characters", "error") : alert("Password must be at least 8 characters");
      return;
    }

    if (state.editingId) {
      const user = state.users.find(u => u.id === state.editingId);
      if (user) {
        user.username = username;
        user.password = password;
        user.tools = tools;
      }
    } else {
      state.users.push({
        id: nextId(), username, password, tools,
        createdAt: new Date().toISOString(),
      });
    }

    saveUsers(state.users);
    renderTable();
    closeModal();
  }

  function deleteUser(userId) {
    state.users = state.users.filter(u => u.id !== userId);
    saveUsers(state.users);
    renderTable();
  }

  /* ─── Wiring ──────────────────────────────────────────────────────────── */
  function wire() {
    document.getElementById("um-add-btn").addEventListener("click", () => openModal(null));
    document.getElementById("um-modal-close-btn").addEventListener("click", closeModal);
    document.getElementById("um-modal-cancel-btn").addEventListener("click", closeModal);
    document.getElementById("um-modal-save-btn").addEventListener("click", saveModal);
    document.getElementById("um-modal-overlay").addEventListener("click", (e) => {
      if (e.target.id === "um-modal-overlay") closeModal();
    });

    document.getElementById("um-password-toggle-btn").addEventListener("click", () => {
      const input = document.getElementById("um-password-input");
      const icon = document.querySelector("#um-password-toggle-btn i");
      const showing = input.type === "text";
      input.type = showing ? "password" : "text";
      if (icon) icon.setAttribute("data-lucide", showing ? "eye" : "eye-off");
      Utils.refreshIcons();
    });

    document.getElementById("um-search-input").addEventListener("input", (e) => {
      state.search = e.target.value;
      renderTable();
    });
  }

  /* ─── Bootstrap ───────────────────────────────────────────────────────── */
  function initPage() {
    state.users = loadUsers();
    wire();
    renderTable();
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (global.Utils && typeof global.Utils.initHeader === "function") {
      global.Utils.initHeader();
    }
    if (global.lucide) {
      global.lucide.createIcons();
    }
  });

  global.onTabActivated = function onTabActivated(isFirstActivation) {
    if (isFirstActivation && !state.loaded) {
      state.loaded = true;
      initPage();
    }
  };

  global.USER_MGMT = {
    reload: renderTable,
    getState: () => Object.assign({}, state),
  };

})(window);
