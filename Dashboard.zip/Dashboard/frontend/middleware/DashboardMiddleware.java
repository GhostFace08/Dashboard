import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.logging.*;

/**
 * DashboardMiddleware — Unified MCP Dashboard backend.
 *
 * REST endpoints:
 *
 *   GET  /api/issues              → serves backend/data/all_issues.json (raw)
 *   GET  /api/status              → returns file-watch metadata + hasNewData flag
 *   POST /api/refresh             → schedules a deferred file check (~60 s)
 *   GET  /api/infrastructure      → serves backend/data/infrastructure.json (raw) (Phase 6)
 *   GET  /api/services            → serves backend/data/services.json (raw) (Phase 7)
 *
 * Config/settings endpoints (GET|PUT /api/config, POST /api/settings/save)
 * have moved to SettingsMiddleware on port 5200.
 *
 * Change 3 additions:
 *   - In-memory metadata store (lastFileTimestamp, lastDataUpdatedAt, lastCheckedAt)
 *   - Background ScheduledExecutorService that polls for a new all_issues.json
 *   - GET /api/status endpoint
 *   - POST /api/refresh endpoint (schedules a one-shot check after 60 s)
 *   - GET /api/issues now adds X-File-Modified-At and X-Server-Time response headers
 *     and injects _fileModifiedAt / _serverTime into the JSON payload
 *
 * HOW TO RUN:
 *   javac DashboardMiddleware.java
 *   java  DashboardMiddleware
 *
 * The server starts on http://localhost:8080 by default.
 * Set PORT env var to override.
 * Set MCP_ROOT env var to point to the project root (default: working dir).
 * Set PERIODIC_CHECK_SECONDS env var to override poll interval (default: 300).
 */
public class DashboardMiddleware {

    // ── Configuration ─────────────────────────────────────────────────────────

    private static final int PORT = Integer.parseInt(
            System.getenv().getOrDefault("PORT", "8080"));

    private static final Path PROJECT_ROOT = Paths.get(
            System.getenv().getOrDefault("MCP_ROOT", ".")).toAbsolutePath();

    private static final Path DATA_DIR   = PROJECT_ROOT.resolve("backend/data");
    private static final Path ISSUES_FILE = DATA_DIR.resolve("all_issues.json");

    /** Phase 6 — Infrastructure page data file */
    private static final Path INFRASTRUCTURE_FILE = DATA_DIR.resolve("infrastructure.json");

    /** Phase 7 — Services page data file */
    private static final Path SERVICES_FILE = DATA_DIR.resolve("services.json");

    /** How often the background thread checks for a new issues file (seconds) */
    private static final long PERIODIC_CHECK_SECONDS = Long.parseLong(
            System.getenv().getOrDefault("PERIODIC_CHECK_SECONDS", "300"));

    /** Delay for a one-shot check triggered by POST /api/refresh (seconds) */
    private static final long REFRESH_CHECK_DELAY_SECONDS = 60L;

    // ── ISO-8601 formatter ────────────────────────────────────────────────────

    private static final DateTimeFormatter ISO = DateTimeFormatter
            .ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC);

    private static String toIso(Instant i) { return i == null ? null : ISO.format(i); }

    // ── Logging ───────────────────────────────────────────────────────────────

    private static final Logger LOG = Logger.getLogger("DashboardMiddleware");

    static {
        LogManager.getLogManager().reset();
        ConsoleHandler ch = new ConsoleHandler();
        ch.setLevel(Level.ALL);
        ch.setFormatter(new SimpleFormatter() {
            @Override public String format(LogRecord r) {
                return String.format("[%s] %s: %s%n", r.getLevel(), r.getLoggerName(), r.getMessage());
            }
        });
        LOG.addHandler(ch);
        LOG.setLevel(Level.INFO);
    }

    // ── Change 3 — In-memory metadata store ──────────────────────────────────

    /** File modification time at the moment data was last loaded onto the dashboard */
    private static volatile Instant lastFileTimestamp = null;

    /** Server wall-clock time when /api/issues last served data to the frontend */
    private static volatile Instant lastDataUpdatedAt = null;

    /** Server wall-clock time of the most recent periodic/one-shot file check */
    private static volatile Instant lastCheckedAt = null;

    /**
     * Set to true by the background thread when it finds a newer file.
     * Cleared to false when /api/issues is served (i.e. the frontend consumed it).
     */
    private static final AtomicBoolean hasNewData = new AtomicBoolean(false);

    /** Executor shared by the periodic check thread and one-shot refresh tasks */
    private static final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "file-watcher");
                t.setDaemon(true);
                return t;
            });

    /**
     * Compares the file's last-modified time to the stored lastFileTimestamp.
     * If newer, sets hasNewData = true and updates lastFileTimestamp.
     * Always updates lastCheckedAt.
     */
    private static void checkFile() {
        try {
            if (!Files.exists(ISSUES_FILE)) {
                lastCheckedAt = Instant.now();
                return;
            }
            FileTime ft = Files.getLastModifiedTime(ISSUES_FILE);
            Instant fileInstant = ft.toInstant();
            lastCheckedAt = Instant.now();

            if (lastFileTimestamp == null || fileInstant.isAfter(lastFileTimestamp)) {
                // Do NOT update lastFileTimestamp here.
                // Only IssuesHandler advances it after the frontend actually consumes
                // the file via GET /api/issues.  If we update it now, a second
                // checkFile() between this moment and the serve would see
                // fileInstant == lastFileTimestamp and silently drop the signal.
                hasNewData.set(true);
                LOG.info("checkFile → new data detected (file ts: " + toIso(fileInstant) + ")");
            }
        } catch (IOException e) {
            LOG.warning("checkFile error: " + e.getMessage());
        }
    }

    // ── Entry point ───────────────────────────────────────────────────────────

    public static void main(String[] args) throws IOException {
        LOG.info("Project root : " + PROJECT_ROOT);
        LOG.info("Data dir     : " + DATA_DIR);
        LOG.info("Issues file  : " + ISSUES_FILE);
        LOG.info("Check interval: " + PERIODIC_CHECK_SECONDS + " s");

        // Seed lastFileTimestamp silently at startup so the first periodic checkFile()
        // does not falsely detect the existing file as "new data".
        // We read the mod-time here WITHOUT setting hasNewData — the frontend will
        // load the file via its own boot GET /api/issues, which will set lastFileTimestamp.
        try {
            if (Files.exists(ISSUES_FILE)) {
                lastFileTimestamp = Files.getLastModifiedTime(ISSUES_FILE).toInstant();
                LOG.info("Startup seed: lastFileTimestamp = " + toIso(lastFileTimestamp));
            }
        } catch (IOException e) {
            LOG.warning("Startup seed failed: " + e.getMessage());
        }

        // Start the background periodic file-check (Change 3).
        // initialDelay = PERIODIC_CHECK_SECONDS (NOT 0) — first check fires after
        // one full interval, not immediately.  Prevents a race where checkFile()
        // runs before the frontend's initial GET /api/issues and spuriously sets
        // hasNewData=true on the file that was just seeded above.
        scheduler.scheduleAtFixedRate(
                DashboardMiddleware::checkFile,
                PERIODIC_CHECK_SECONDS,   // first check after one full interval
                PERIODIC_CHECK_SECONDS,
                TimeUnit.SECONDS
        );

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        server.createContext("/api/issues",         new IssuesHandler());
        server.createContext("/api/status",         new StatusHandler());
        server.createContext("/api/refresh",        new RefreshHandler());
        server.createContext("/api/infrastructure", new InfrastructureHandler());
        server.createContext("/api/services",       new ServicesHandler());

        server.setExecutor(Executors.newFixedThreadPool(4));
        server.start();

        LOG.info("DashboardMiddleware listening on http://localhost:" + PORT);
        LOG.info("  GET  /api/issues");
        LOG.info("  GET  /api/status");
        LOG.info("  POST /api/refresh");
        LOG.info("  GET  /api/infrastructure");
        LOG.info("  GET  /api/services");
        LOG.info("  Config/settings endpoints have moved to SettingsMiddleware (:5200)");
    }

    // ── Shared helpers ────────────────────────────────────────────────────────

    private static void addCors(HttpExchange ex) {
        ex.getResponseHeaders().set("Access-Control-Allow-Origin",  "*");
        ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, PUT, POST, OPTIONS");
        ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
    }

    private static void send(HttpExchange ex, int status, String contentType, String body)
            throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", contentType);
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    private static void sendJson(HttpExchange ex, String json) throws IOException {
        send(ex, 200, "application/json; charset=utf-8", json);
    }

    private static void sendText(HttpExchange ex, String text) throws IOException {
        send(ex, 200, "text/plain; charset=utf-8", text);
    }

    private static void sendError(HttpExchange ex, int status, String message)
            throws IOException {
        String json = "{\"error\":\"" + message.replace("\"", "'") + "\"}";
        send(ex, status, "application/json; charset=utf-8", json);
    }

    private static String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Handler: GET /api/issues  (Change 3 — adds server timestamps to response)
    // ─────────────────────────────────────────────────────────────────────────

    static class IssuesHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            addCors(ex);
            if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.sendResponseHeaders(204, -1);
                return;
            }
            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendError(ex, 405, "Method not allowed");
                return;
            }

            Instant serverNow = Instant.now();

            if (Files.exists(ISSUES_FILE)) {
                String json = Files.readString(ISSUES_FILE, StandardCharsets.UTF_8);

                // Change 3 — update metadata.
                // lastCheckedAt is intentionally NOT updated here — only checkFile()
                // owns it.  Mixing it here caused the status bar to show the data-serve
                // time as the "last checked" time, which is semantically wrong.
                FileTime ft = Files.getLastModifiedTime(ISSUES_FILE);
                Instant fileInstant = ft.toInstant();
                lastFileTimestamp  = fileInstant;   // when the file was last written
                lastDataUpdatedAt  = serverNow;     // when the frontend loaded it
                hasNewData.set(false);              // frontend consumed the data

                // Add server-time response headers
                ex.getResponseHeaders().set("X-File-Modified-At", toIso(fileInstant));
                ex.getResponseHeaders().set("X-Server-Time",      toIso(serverNow));

                // Inject timestamps into the JSON payload so dashboard.js can
                // read them even when headers are stripped (e.g. by a proxy).
                // We append before the closing } of the top-level object.
                String stamped = injectTimestamps(json, fileInstant, serverNow);

                LOG.info("GET /api/issues → " + ISSUES_FILE.getFileName()
                        + " (" + stamped.length() + " bytes)");
                sendJson(ex, stamped);
            } else {
                LOG.warning("GET /api/issues → file not found: " + ISSUES_FILE);
                sendJson(ex, "{\"allIssues\":[]}");
            }
        }

        /**
         * Injects _fileModifiedAt and _serverTime into a top-level JSON object
         * string without a full parse.  Locates the last `}` and inserts before it.
         */
        private static String injectTimestamps(String json, Instant fileTs, Instant serverTs) {
            String fm = toIso(fileTs);
            String st = toIso(serverTs);
            String extra = ",\"_fileModifiedAt\":\"" + fm + "\",\"_serverTime\":\"" + st + "\"";
            int last = json.lastIndexOf('}');
            if (last < 0) return json + "{" + extra.substring(1) + "}";
            return json.substring(0, last) + extra + json.substring(last);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Change 3 — Handler: GET /api/status
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns current middleware metadata so the JS poller can decide whether
     * to pull fresh data.
     *
     * Response body:
     * {
     *   "lastFileModifiedAt": "2024-01-15T12:00:30Z",   // null if never loaded
     *   "lastDataUpdatedAt":  "2024-01-15T12:01:00Z",   // null if never served
     *   "lastCheckedAt":      "2024-01-15T12:06:00Z",   // null if never checked
     *   "hasNewData": false
     * }
     */
    static class StatusHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            addCors(ex);
            if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.sendResponseHeaders(204, -1);
                return;
            }
            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendError(ex, 405, "Method not allowed");
                return;
            }

            String json = "{"
                    + "\"lastFileModifiedAt\":" + jsonStr(toIso(lastFileTimestamp)) + ","
                    + "\"lastDataUpdatedAt\":"  + jsonStr(toIso(lastDataUpdatedAt)) + ","
                    + "\"lastCheckedAt\":"      + jsonStr(toIso(lastCheckedAt))     + ","
                    + "\"hasNewData\":"         + hasNewData.get()
                    + "}";

            LOG.fine("GET /api/status → " + json);
            sendJson(ex, json);
        }

        private static String jsonStr(String s) {
            return s == null ? "null" : "\"" + s + "\"";
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Change 3 — Handler: POST /api/refresh
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Tells the middleware that the Java fetch service has been triggered by
     * the user pressing the Refresh button.  Schedules a one-shot file check
     * after REFRESH_CHECK_DELAY_SECONDS (60 s) so the new file (if any) will
     * be detected by the next /api/status poll.
     *
     * Response: { "scheduled": true, "checkIn": 60 }
     */
    static class RefreshHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            addCors(ex);
            if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.sendResponseHeaders(204, -1);
                return;
            }
            if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                sendError(ex, 405, "Method not allowed");
                return;
            }

            scheduler.schedule(
                    DashboardMiddleware::checkFile,
                    REFRESH_CHECK_DELAY_SECONDS,
                    TimeUnit.SECONDS
            );

            LOG.info("POST /api/refresh → one-shot check scheduled in "
                    + REFRESH_CHECK_DELAY_SECONDS + " s");

            sendJson(ex, "{\"scheduled\":true,\"checkIn\":" + REFRESH_CHECK_DELAY_SECONDS + "}");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Phase 6 — Handler: GET /api/infrastructure
    //
    // Deliberately a lean mirror of IssuesHandler: same file-serve pattern
    // (read the JSON file, hand it back as-is, empty-array fallback if
    // missing), but WITHOUT the Change-3 lastFileTimestamp/hasNewData/
    // X-File-Modified-At machinery — the Infrastructure page has no
    // countdown timer or status bar to feed, so that bookkeeping would be
    // dead weight here. If a future phase adds polling/refresh to this page,
    // that tracking can be added the same way it was for IssuesHandler.
    // ─────────────────────────────────────────────────────────────────────────

    static class InfrastructureHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            addCors(ex);
            if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.sendResponseHeaders(204, -1);
                return;
            }
            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendError(ex, 405, "Method not allowed");
                return;
            }

            if (Files.exists(INFRASTRUCTURE_FILE)) {
                String json = Files.readString(INFRASTRUCTURE_FILE, StandardCharsets.UTF_8);
                LOG.info("GET /api/infrastructure → " + INFRASTRUCTURE_FILE.getFileName()
                        + " (" + json.length() + " bytes)");
                sendJson(ex, json);
            } else {
                LOG.warning("GET /api/infrastructure → file not found: " + INFRASTRUCTURE_FILE);
                sendJson(ex, "{\"infrastructure\":[]}");
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Phase 7 — Handler: GET /api/services
    //
    // Identical pattern to InfrastructureHandler (Phase 6) — same lean
    // file-serve, no Change-3 timestamp tracking. If Infrastructure ever
    // grows that tracking back in, do the same here for consistency.
    // ─────────────────────────────────────────────────────────────────────────

    static class ServicesHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            addCors(ex);
            if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.sendResponseHeaders(204, -1);
                return;
            }
            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendError(ex, 405, "Method not allowed");
                return;
            }

            if (Files.exists(SERVICES_FILE)) {
                String json = Files.readString(SERVICES_FILE, StandardCharsets.UTF_8);
                LOG.info("GET /api/services → " + SERVICES_FILE.getFileName()
                        + " (" + json.length() + " bytes)");
                sendJson(ex, json);
            } else {
                LOG.warning("GET /api/services → file not found: " + SERVICES_FILE);
                sendJson(ex, "{\"services\":[]}");
            }
        }
    }

}